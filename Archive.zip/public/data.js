"use strict";

(function(exports) {
  exports.people =[ 
    {
      "name": "Robert(Lee) Smith and Family",
      "address": "805 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Evans/Tisdale/Griffith",
      "address": "893 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Storeys",
      "address": "937 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Jeffries",
      "address": "942 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Russells",
      "address": "943 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Felders",
      "address": "969 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Eiler/Evans/Goodwin",
      "address": "973 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Hitchcock/Harvey/Dillon",
      "address": "961 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    },
    {
      "name": "Jamieson/Metcalfs",
      "address": "921 Ocean Blvd. W, Holden Beach, NC",
      "contact": []
    }]

  
  exports.test=function() {
    return 'hello world';
  };

})(typeof exports === 'undefined' ? this['data']={}: exports);